import praw

reddit = praw.Reddit(
    client_id="Your_id",
    client_secret="your_secret",
    user_agent="name"
)

def scrape_reddit(query, subreddit="all", n_posts=3, n_comments=5):
    results = []
    sub = reddit.subreddit(subreddit)
    for post in sub.search(query, limit=n_posts):
        post_data = {
            "title": post.title,
            "url": post.url,
            "comments": []
        }
        post.comments.replace_more(limit=0)
        for comment in post.comments[:n_comments]:
            post_data["comments"].append(comment.body)
        results.append(post_data)
    return results


# Example use
if __name__ == "__main__":
    data = scrape_reddit("people", subreddit="bangalore", n_posts=2, n_comments=5)
    for post in data:
        print("Post:", post["title"])
        for c in post["comments"]:
            print("   Comment:", c)
