from keybert import KeyBERT

kw_model = KeyBERT()
text = "Does anyone else feel that the dust in Bangalore is frustrating?"
keywords = kw_model.extract_keywords(text, top_n=3)
print(keywords)