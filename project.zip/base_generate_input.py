import csv
import re
from google import genai

# Initialize Gemini client
client = genai.Client(api_key="Your_key")

# Prompt for queries
response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents="""Generate 100 realistic, casual social-media style questions that young people are interested in, when they want to discuss hidden or unorthodox issues of daily life.  
The questions should sound natural, like how people actually complain or ask on Reddit. 
Focus more on topics that are not typically covered in official surveys or news reports — examples: dust in Bangalore, pollen allergies, rising rents, hostel food quality, traffic after metro construction, cost of coffee, loneliness, job stress, mental health, nightlife, odd weather, etc.  

Make each query short and conversational (1–2 sentences). 
Only return the queries in a clean numbered list, no explanations."""
)

# Extract text
output_text = response.text

# Parse queries (remove numbers, keep text only)
queries = re.findall(r"\d+\.\s*(.+)", output_text)

# Save to CSV
with open("user_queries.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["query"])  # header
    for q in queries:
        writer.writerow([q.strip()])

print("✅ Saved 100 queries to user_queries.csv")