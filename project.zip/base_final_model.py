from transformers import pipeline
import pandas as pd

# Load dataset
df = pd.read_csv("final_model_data.csv")

# Load pretrained summarizer (BART)
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

for idx, row in df.iterrows():
    query = row["query"]
    context = row["context"]
    combined_text = f"User query: {query}\nContext: {context}"
    
    summary = summarizer(combined_text, max_length=50, min_length=10, do_sample=False)
    print(f"🔹 Query: {query}")
    print(f"📝 Model Insight: {summary[0]['summary_text']}")
    print("="*60)